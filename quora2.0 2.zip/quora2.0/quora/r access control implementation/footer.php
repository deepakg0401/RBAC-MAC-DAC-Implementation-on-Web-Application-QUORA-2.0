<footer>
    <div class="panel panel-default">
        <div class="panel-body small">
            <span>Copyright &copy; <?= (date('Y') !== '2017' ? '2017-' : '') . date('Y') ?> <a href="https://github.com/hamza1886" target="_blank">Hamza Rashid</a>. All rights reserved.</span>

            <span class="pull-right"><a href="https://github.com/hamza1886/role-based-access-control#license" target="_blank">License</a></span>
        </div>
    </div>
</footer>
# quora2.0
question answering platform
DBMS: Souhard Kataria (17CO147) & Tushar Dubey (17CO149)
Information Security: Souhard Kataria (17CO147) & Deepak Garhwal (17EE115)
